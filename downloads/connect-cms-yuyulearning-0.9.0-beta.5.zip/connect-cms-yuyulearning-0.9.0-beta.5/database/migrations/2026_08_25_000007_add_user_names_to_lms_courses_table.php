<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('yuyu_learning_courses', function (Blueprint $table) {
            $table->string('created_name')->nullable()->after('created_id');
            $table->string('updated_name')->nullable()->after('updated_id');
        });
    }

    public function down(): void
    {
        Schema::table('yuyu_learning_courses', function (Blueprint $table) {
            $table->dropColumn(['created_name', 'updated_name']);
        });
    }
};
